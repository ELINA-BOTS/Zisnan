# ⏩Auto forward bot

# Devs
• We have used <a href="https://t.me/KingVJ01">King VJ's</a> source code <br>
• Errors in this repo are fixed by <a href="https://t.me/EK4MPREETSINGH">Ekampreet Singh</a>  
